# Gachi touchbar
<img src="https://i.imgur.com/A2ONEws.png">

Make the Touch Bar great again!


## Preview: https://i.nuuls.com/Ru0XV.mp4
